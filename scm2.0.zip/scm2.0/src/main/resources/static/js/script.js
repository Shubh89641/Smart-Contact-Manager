console.log("Script loaded");

// change theme work
let currentTheme = getTheme();
//initial -->

document.addEventListener("DOMContentLoaded", () => {
  changeTheme();
});

//TODO:
function changeTheme() {
  //set to web page

  changePageTheme(currentTheme, "");
  //set the listener to change theme button
  const changeThemeButton = document.querySelector("#theme_change_button");

  changeThemeButton.addEventListener("click", (event) => {
    let oldTheme = currentTheme;
    console.log("change theme button clicked");
    if (currentTheme === "dark") {
      //theme ko light
      currentTheme = "light";
    } else {
      //theme ko dark
      currentTheme = "dark";
    }
    console.log(currentTheme);
    changePageTheme(currentTheme, oldTheme);
  });
}

//set theme to localstorage
function setTheme(theme) {
  localStorage.setItem("theme", theme);
}

//get theme from localstorage
function getTheme() {
  let theme = localStorage.getItem("theme");
  return theme ? theme : "light";
}

//change current page theme
function changePageTheme(theme, oldTheme) {
  //localstorage mein update karenge
  setTheme(currentTheme);
  //remove the current theme

  if (oldTheme) {
    document.querySelector("html").classList.remove(oldTheme);
  }
  //set the current theme
  document.querySelector("html").classList.add(theme);

  // change the text of button
  document
    .querySelector("#theme_change_button")
    .querySelector("span").textContent = theme == "light" ? "Dark" : "Light";
}


//change page change theme

    document.addEventListener("DOMContentLoaded", function () {
        const chatbotToggle = document.getElementById("chatbot-toggle");
        const chatbotPopup = document.getElementById("chatbot-popup");
        const closeChatbot = document.getElementById("close-chatbot");
        const chatbotInput = document.getElementById("chatbot-input");
        const chatbotMessages = document.getElementById("chatbot-messages");
        const sendChatbotMessage = document.getElementById("send-chatbot-message");

        // Toggle Chatbot
        chatbotToggle.addEventListener("click", () => {
            chatbotPopup.classList.toggle("hidden");
        });

        // Close Chatbot
        closeChatbot.addEventListener("click", () => {
            chatbotPopup.classList.add("hidden");
        });

        // Send Message Function
        async function sendMessage() {
            const userMessage = chatbotInput.value.trim();
            if (!userMessage) return;

            // Append user message
            chatbotMessages.innerHTML += `<div class="bg-gray-200 dark:bg-gray-600 p-2 my-2 rounded-lg text-right">
                <span>${userMessage}</span>
            </div>`;

            chatbotInput.value = "";
            chatbotMessages.scrollTop = chatbotMessages.scrollHeight;

            try {
                const response = await fetch("/api/ai-chat", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ message: userMessage })
                });

                const data = await response.json();
                const botReply = data.reply || "Sorry, I couldn't understand that.";

                // Append bot response
                chatbotMessages.innerHTML += `<div class="bg-blue-500 text-white p-2 my-2 rounded-lg text-left">
                    <span>${botReply}</span>
                </div>`;

                chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
            } catch (error) {
                chatbotMessages.innerHTML += `<div class="bg-red-500 text-white p-2 my-2 rounded-lg text-left">
                    <span>Error fetching response.</span>
                </div>`;
            }
        }

        // Send message on button click
        sendChatbotMessage.addEventListener("click", sendMessage);

        // Send message on Enter key press
        chatbotInput.addEventListener("keypress", function (e) {
            if (e.key === "Enter") sendMessage();
        });
    });
    

