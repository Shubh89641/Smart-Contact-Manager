package com.scm.controllers;

import com.scm.entities.Message;
import com.scm.repsitories.MessageRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
public class MessageRestController {

    private final MessageRepository messageRepository;

    public MessageRestController(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    @GetMapping("/{sender}/{receiver}")
    public List<Message> getChatHistory(@PathVariable String sender, @PathVariable String receiver) {
        return messageRepository.findBySenderAndReceiver(sender, receiver);
    }
}
