package com.scm.controllers;

import com.scm.entities.Message;
import com.scm.repsitories.MessageRepository;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.util.Date;

@Controller
public class MessageController {

    private final MessageRepository messageRepository;

    public MessageController(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    @MessageMapping("/chat")  // Must match "/app/chat" from the frontend
    @SendTo("/topic/messages")  // Clients subscribed to "/topic/messages" will receive it
    public Message sendMessage(Message message) {
        message.setTimestamp(new Date());
        messageRepository.save(message);
        return message;
    }
}
