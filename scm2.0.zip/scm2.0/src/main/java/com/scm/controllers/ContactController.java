package com.scm.controllers;

import java.util.UUID;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.scm.entities.Contact;
import com.scm.entities.User;
import com.scm.forms.ContactForm;
import com.scm.forms.ContactSearchForm;
import com.scm.helpers.AppConstants;
import com.scm.helpers.Helper;
import com.scm.helpers.Message;
import com.scm.helpers.MessageType;
import com.scm.services.ContactService;
import com.scm.services.ImageService;
import com.scm.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/user/contacts")
public class ContactController {

    private final Logger logger = org.slf4j.LoggerFactory.getLogger(ContactController.class);

    @Autowired
    private ContactService contactService;

    @Autowired
    private ImageService imageService;

    @Autowired
    private UserService userService;

    /**
     * Load Add Contact Form
     */
    @GetMapping("/add")
    public String addContactView(Model model) {
        model.addAttribute("contactForm", new ContactForm());
        return "user/add_contact";
    }

    /**
     * Save a New Contact with Duplicate Check
     */
    @PostMapping("/add")
    public String saveContact(@Valid @ModelAttribute ContactForm contactForm, BindingResult result,
                              Authentication authentication, HttpSession session) {

        if (result.hasErrors()) {
            session.setAttribute("message", Message.builder()
                    .content("Please correct the following errors")
                    .type(MessageType.red)
                    .build());
            return "user/add_contact";
        }

        String username = Helper.getEmailOfLoggedInUser(authentication);
        User user = userService.getUserByEmail(username);

        // Check if email already exists
        boolean emailExists = contactService.getByUserId(user.getUserId()).stream()
                .anyMatch(c -> c.getEmail().equalsIgnoreCase(contactForm.getEmail()));

        if (emailExists) {
            session.setAttribute("message",
                    Message.builder().content("A contact with this email already exists!")
                            .type(MessageType.red).build());
            return "user/add_contact";
        }

        Contact contact = new Contact();
        contact.setName(contactForm.getName());
        contact.setFavorite(contactForm.isFavorite());
        contact.setEmail(contactForm.getEmail());
        contact.setPhoneNumber(contactForm.getPhoneNumber());
        contact.setAddress(contactForm.getAddress());
        contact.setDescription(contactForm.getDescription());
        contact.setUser(user);
        contact.setLinkedInLink(contactForm.getLinkedInLink());
        contact.setWebsiteLink(contactForm.getWebsiteLink());
        contact.setDob(contactForm.getDob());

        if (contactForm.getContactImage() != null && !contactForm.getContactImage().isEmpty()) {
            String filename = UUID.randomUUID().toString();
            String fileURL = imageService.uploadImage(contactForm.getContactImage(), filename);
            contact.setPicture(fileURL);
            contact.setCloudinaryImagePublicId(filename);
        }

        contactService.save(contact);
        session.setAttribute("message",
                Message.builder()
                        .content("Contact added successfully!")
                        .type(MessageType.green)
                        .build());

                        return "redirect:/user/dashboard";
    }

    /**
     * View Contacts with Birthday Notifications
     */
    @GetMapping
    public String viewContacts(@RequestParam(value = "page", defaultValue = "0") int page,
                               @RequestParam(value = "size", defaultValue = AppConstants.PAGE_SIZE + "") int size,
                               @RequestParam(value = "sortBy", defaultValue = "name") String sortBy,
                               @RequestParam(value = "direction", defaultValue = "asc") String direction,
                               Model model, Authentication authentication, HttpSession session) {

        String username = Helper.getEmailOfLoggedInUser(authentication);
        User user = userService.getUserByEmail(username);

        Page<Contact> pageContact = contactService.getByUser(user, page, size, sortBy, direction);
        model.addAttribute("pageContact", pageContact);
        model.addAttribute("pageSize", AppConstants.PAGE_SIZE);
        model.addAttribute("contactSearchForm", new ContactSearchForm());

        // 🎂 Check for Today's Birthdays (Multiple Contacts)
        LocalDate today = LocalDate.now();
        List<Contact> contacts = contactService.getByUserId(user.getUserId());

        List<String> birthdayContacts = contacts.stream()
                .filter(c -> c.getDob() != null &&
                        c.getDob().getMonth() == today.getMonth() &&
                        c.getDob().getDayOfMonth() == today.getDayOfMonth())
                .map(Contact::getName)
                .collect(Collectors.toList());

        if (!birthdayContacts.isEmpty()) {
            session.setAttribute("message",
                    Message.builder()
                            .content("🎂 Today is " + String.join(", ", birthdayContacts) + "'s Birthday!")
                            .type(MessageType.green)
                            .build());
        }

        return "user/contacts";
    }

    /**
     * Redirect to Contact's LinkedIn Profile
     */
    @GetMapping("/linkedin/{contactId}")
    public String redirectToLinkedIn(@PathVariable("contactId") String contactId) {
        Contact contact = contactService.getById(contactId);
        if (contact.getLinkedInLink() != null && !contact.getLinkedInLink().isEmpty()) {
            return "redirect:" + contact.getLinkedInLink();
        }
        return "redirect:https://www.linkedin.com";
    }

    // search handler

    @RequestMapping("/search")
    public String searchHandler(
            @ModelAttribute ContactSearchForm contactSearchForm,
            @RequestParam(value = "size", defaultValue = AppConstants.PAGE_SIZE + "") int size,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "sortBy", defaultValue = "name") String sortBy,
            @RequestParam(value = "direction", defaultValue = "asc") String direction,
            Model model,
            Authentication authentication) {
    
        logger.info("Search Field: {}, Keyword: {}", contactSearchForm.getField(), contactSearchForm.getValue());
    
        var user = userService.getUserByEmail(Helper.getEmailOfLoggedInUser(authentication));
    
        Page<Contact> pageContact = Page.empty(); // Ensure it's never null
    
        if (contactSearchForm.getField() != null && contactSearchForm.getValue() != null) {
            switch (contactSearchForm.getField().toLowerCase()) {
                case "name":
                    pageContact = contactService.searchByName(contactSearchForm.getValue(), size, page, sortBy, direction, user);
                    break;
                case "email":
                    pageContact = contactService.searchByEmail(contactSearchForm.getValue(), size, page, sortBy, direction, user);
                    break;
                case "phone":
                    pageContact = contactService.searchByPhoneNumber(contactSearchForm.getValue(), size, page, sortBy, direction, user);
                    break;
                default:
                    logger.warn("Invalid search field provided.");
            }
        }
    
        model.addAttribute("contactSearchForm", contactSearchForm);
        model.addAttribute("pageContact", pageContact);
        model.addAttribute("pageSize", AppConstants.PAGE_SIZE);
    
        return "user/search";
    }
    

    // detete contact
    @RequestMapping("/delete/{contactId}")
    public String deleteContact(
            @PathVariable("contactId") String contactId,
            HttpSession session) {
        contactService.delete(contactId);
        logger.info("contactId {} deleted", contactId);

        session.setAttribute("message",
                Message.builder()
                        .content("Contact is Deleted successfully !! ")
                        .type(MessageType.green)
                        .build()

        );

        return "redirect:/user/dashboard";
    }
    /**
     * Load Update Contact Form
     */
    @GetMapping("/view/{contactId}")
    public String updateContactFormView(@PathVariable("contactId") String contactId, Model model) {
        Contact contact = contactService.getById(contactId);
        ContactForm contactForm = new ContactForm();
        contactForm.setName(contact.getName());
        contactForm.setEmail(contact.getEmail());
        contactForm.setPhoneNumber(contact.getPhoneNumber());
        contactForm.setAddress(contact.getAddress());
        contactForm.setDescription(contact.getDescription());
        contactForm.setFavorite(contact.isFavorite());
        contactForm.setWebsiteLink(contact.getWebsiteLink());
        contactForm.setLinkedInLink(contact.getLinkedInLink());
        contactForm.setPicture(contact.getPicture());
        contactForm.setDob(contact.getDob());

        model.addAttribute("contactForm", contactForm);
        model.addAttribute("contactId", contactId);
        return "user/update_contact_view";
    }
}
