package com.scm.controllers;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.io.Reader;
import java.io.InputStreamReader;

import com.scm.entities.Contact;
import com.scm.services.ContactService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api")  // Ensure this matches frontend API calls
public class UserContactController {

    private static final Logger logger = LoggerFactory.getLogger(UserContactController.class);

    @Autowired
    private ContactService contactService;
    @PostMapping("/contacts/import")
    public ResponseEntity<Map<String, String>> importContacts(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "File is empty!"));
        }
    
        try (Reader reader = new InputStreamReader(file.getInputStream());
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {
    
            List<Contact> contacts = new ArrayList<>();
            for (CSVRecord record : csvParser) {
                Contact contact = new Contact();
                contact.setName(record.get("Name"));
                contact.setEmail(record.get("Email"));
                contact.setPhoneNumber(record.get("Phone"));
                contact.setWebsiteLink(record.get("Website"));
                
                // Ensure the contact ID is not mistakenly set
                if (record.isSet("ID") && !record.get("ID").isEmpty()) {
                    try {
                        Long id = Long.parseLong(record.get("ID"));
                        logger.warn("Skipping setting ID {} for new contact import", id);
                    } catch (NumberFormatException e) {
                        logger.error("Invalid ID found in CSV: {}", record.get("ID"));
                    }
                }
    
                contacts.add(contact);
            }
    
            contactService.saveAll(contacts);
            return ResponseEntity.ok(Map.of("message", "Contacts imported successfully!"));
    
        } catch (Exception e) {
            logger.error("CSV Processing Error: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("message", "Error processing CSV file"));
        }
    }
    
}
