package com.scm.controllers;

import com.scm.entities.Feedback;
import com.scm.services.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Logger;

@Controller
@RequestMapping("/feedback")
public class FeedbackController {

    private static final Logger LOGGER = Logger.getLogger(FeedbackController.class.getName());

    @Autowired
    private FeedbackService feedbackService;

    // ✅ Load Feedback Page
    @GetMapping
    public String feedbackPage(Model model) {
        List<Feedback> feedbackList = feedbackService.getAllFeedbacks();
        model.addAttribute("feedbackMessage", "We value your feedback!");
        model.addAttribute("feedback", new Feedback());
        model.addAttribute("feedbackList", feedbackList);
        return "feedback"; // Ensure feedback.html exists
    }

    // ✅ Handle Feedback Submission
    @PostMapping("/submit")
    public String submitFeedback(@ModelAttribute Feedback feedback) {
        LOGGER.info("Received Feedback: " + feedback);
        feedbackService.saveFeedback(feedback);
        return "redirect:/feedback";
    }

    // ✅ API to Get All Feedbacks (AJAX)
    @GetMapping("/all")
    @ResponseBody
    public ResponseEntity<List<Feedback>> getAllFeedbacks() {
        List<Feedback> feedbackList = feedbackService.getAllFeedbacks();
        LOGGER.info("Feedback Data: " + feedbackList);
        return ResponseEntity.ok(feedbackList);
    }
}