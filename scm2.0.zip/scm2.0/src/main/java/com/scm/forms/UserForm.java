package com.scm.forms;

import org.springframework.format.annotation.DateTimeFormat;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class UserForm {

    @NotBlank(message = "Username is required")
    @Size(min = 3, message = "Username must be at least 3 characters long")
    private String name;

    @Email(message = "Invalid Email Address")
    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters long")
    private String password;

    @NotBlank(message = "About is required")
    private String about;

    @NotBlank(message = "Phone Number is required")
    @Pattern(regexp = "^[0-9]{10,12}$", message = "Phone number must be between 10-12 digits")
    private String phoneNumber;

    @NotNull(message = "Date of Birth is required")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)  // Ensures format YYYY-MM-DD
    private LocalDate dob;
}
