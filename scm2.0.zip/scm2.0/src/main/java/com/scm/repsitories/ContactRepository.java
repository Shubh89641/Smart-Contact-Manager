package com.scm.repsitories;

import com.scm.entities.Contact;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface ContactRepository extends JpaRepository<Contact, String> {
    long countByUser_UserId(String userId);
    List<Contact> findTop5ByUser_UserIdOrderByCreatedAtDesc(String userId);
    List<Contact> findByDob(LocalDate dob);
    
}
