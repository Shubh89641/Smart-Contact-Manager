package com.scm.entities;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import com.scm.services.ContactService; // Add this import statement
import com.scm.services.EmailService; // Add this import statement

@Service
public class BirthdayNotificationService {

    @Autowired
    private ContactService contactService;

    @Autowired
    private EmailService emailService;  // Assume an EmailService is implemented

    @Scheduled(cron = "0 0 8 * * ?") // Runs every day at 8 AM
    public void sendBirthdayNotifications() {
        LocalDate today = LocalDate.now();
        List<Contact> contacts = contactService.getContactsByBirthday(today);

        for (Contact contact : contacts) {
            String emailContent = "🎉 Happy Birthday, " + contact.getName() + "! 🎂\nWishing you a fantastic day!";
            emailService.sendEmail(contact.getEmail(), "Happy Birthday!", emailContent);
            System.out.println("Birthday notification sent to: " + contact.getEmail());
        }
    }
}
