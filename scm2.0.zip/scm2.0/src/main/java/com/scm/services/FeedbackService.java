package com.scm.services;

import com.scm.entities.Feedback;
import java.util.List;

public interface FeedbackService {
    void saveFeedback(Feedback feedback);
    List<Feedback> getAllFeedbacks();
}