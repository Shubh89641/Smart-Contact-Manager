package com.scm.config;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.scm.entities.Providers;
import com.scm.entities.User;
import com.scm.helpers.AppConstants;
import com.scm.repsitories.UserRepo;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class OAuthAuthenicationSuccessHandler implements AuthenticationSuccessHandler {

    Logger logger = LoggerFactory.getLogger(OAuthAuthenicationSuccessHandler.class);

    @Autowired
    private UserRepo userRepo;

    @Override
    public void onAuthenticationSuccess(
            HttpServletRequest request,
            HttpServletResponse response,
            Authentication authentication) throws IOException, ServletException {

        logger.info("OAuthAuthenicationSuccessHandler triggered...");

        var oauth2AuthenicationToken = (OAuth2AuthenticationToken) authentication;
        String provider = oauth2AuthenicationToken.getAuthorizedClientRegistrationId();
        logger.info("Provider: {}", provider);

        var oauthUser = (DefaultOAuth2User) authentication.getPrincipal();
        oauthUser.getAttributes().forEach((key, value) -> logger.info("{} : {}", key, value));

        String email = oauthUser.getAttribute("email") != null ? oauthUser.getAttribute("email").toString() : null;
        String profilePic = oauthUser.getAttribute("picture") != null ? oauthUser.getAttribute("picture").toString() : null;
        String name = oauthUser.getAttribute("name") != null ? oauthUser.getAttribute("name").toString() : null;
        String providerUserId = oauthUser.getName();

        if (email == null) {
            logger.error("OAuth authentication failed: Email not found");
            response.sendRedirect("/login?error=email_missing");
            return;
        }

        // Check if user already exists
        User user = userRepo.findByEmail(email).orElse(null);
        if (user == null) {
            user = new User();
            user.setUserId(UUID.randomUUID().toString());
            user.setEmail(email);
            user.setProfilePic(profilePic);
            user.setName(name);
            user.setProviderUserId(providerUserId);
            user.setProvider(Providers.valueOf(provider.toUpperCase()));
            user.setAbout("This account is created using " + provider);
            user.setEnabled(true);
            user.setEmailVerified(true);
            user.setPassword("dummy");
            user.setRoleList(new HashSet<>(Set.of(AppConstants.ROLE_USER))); // ✅ Fix: Convert List to Set

            userRepo.save(user);
            logger.info("New user created: {}", email);
        } else {
            logger.info("User already exists: {}", email);
        }

        new DefaultRedirectStrategy().sendRedirect(request, response, "/user/profile");
    }
}
