package com.scm.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import com.scm.services.impl.SecurityCustomUserDetailService;

@Configuration
public class SecurityConfig {

    private final SecurityCustomUserDetailService userDetailService;
    private final OAuthAuthenicationSuccessHandler handler;
    private final AuthFailtureHandler authFailtureHandler;

    public SecurityConfig(SecurityCustomUserDetailService userDetailService, 
                          OAuthAuthenicationSuccessHandler handler, 
                          AuthFailtureHandler authFailtureHandler) {
        this.userDetailService = userDetailService;
        this.handler = handler;
        this.authFailtureHandler = authFailtureHandler;
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
        daoAuthenticationProvider.setUserDetailsService(userDetailService);
        daoAuthenticationProvider.setPasswordEncoder(passwordEncoder());
        return daoAuthenticationProvider;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/user/**").authenticated()
                .anyRequest().permitAll()
            )
            .formLogin(formLogin -> formLogin
                .loginPage("/login")
                .loginProcessingUrl("/authenticate")
                .defaultSuccessUrl("/user/profile", true)
                .usernameParameter("email")
                .passwordParameter("password")
                .failureHandler(authFailtureHandler)
            )
            .csrf(csrf -> csrf.disable())  // Disable CSRF if necessary (Ensure CSRF protection where required)
            .oauth2Login(oauth -> oauth
                .loginPage("/login")
                .successHandler(handler)
            )
            .logout(logout -> logout
                .logoutUrl("/do-logout") // Logout URL
                .logoutSuccessUrl("/login?logout=true") // Redirect to login page after logout
                .invalidateHttpSession(true) // Invalidate session
                .deleteCookies("JSESSIONID") // Delete session cookie
            );

        return httpSecurity.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
